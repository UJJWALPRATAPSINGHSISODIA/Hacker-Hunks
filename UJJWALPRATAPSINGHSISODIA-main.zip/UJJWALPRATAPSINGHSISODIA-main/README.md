# BrightBrain
#Website Link : https://umar-ashraf09.github.io/BrightBrain/Home.html

BrightBrain - An All-In-One Student Resource Platform
I with two team-mates created BrightBrain - An All-In-One Student Resource Platform with video lectures, tutorials, tools, and projects. Our aim is to enhance students' academic experience and skills by simplifying the process of finding reliable online resources.
